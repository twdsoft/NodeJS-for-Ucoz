System.register(["./chunk-get-repo-element.js","./chunk-vendor.js","./chunk-frameworks.js"],function(){"use strict";return{setters:[function(){},function(){},function(){}],execute:function(){}}});
//# sourceMappingURL=code-menu-50869d48.js.map
